#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

int main(){
	int *cptr,*mptr,i,j,sum=0,n;
	printf("\nenter the number of elements");
	scanf("%d",&n);
	
	mptr = (int*) malloc(n * sizeof(int));
	
	
}
