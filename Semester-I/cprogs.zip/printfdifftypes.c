#include <stdio.h>

void main()
{
	system("cls");
	int var = 15;
	printf("var Decimal= %d\n",var);
	printf("var Octal = %o\n",var);
	printf("var Hexa = %x\n",var);
	printf("var Char = %c\n",var);
	printf("var Int = %i\n",var);
	printf("var Float = %f\n",var);
	printf("var Unknown Decimal = %u\n",var);
	printf("var Expo = %e\n",var);
	printf("var Expo2 = %g\n",var);
	printf("var Ptr = %p\n",var);
	printf("var Str = %s\n",var);
	getchar();
}
