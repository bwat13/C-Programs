#include <stdio.h>
#include <conio.h>

int readArray(int M[][]);
int printArray(int M[][]);
int setMat(int M[][]);
int printMat(int M[][])
void main()
{
	int i,j,t,A[50][50],B[50][50],C[50][50];
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			C[i][j]=A[i][j]+B[i][j];
		}
	}
}
